# FishONet v109 — Compact Email Code Package

This compact package accompanies the FishONet technical report. It contains the
important source code, environment definition, class metadata, learned quota-gate and
re-ranker checkpoints, and the exact official v109 reference prediction.

Official result: **53.76139071919248% overall**
(77.00% photographed / 23.77% unseen), rank #3, CWNU AIX.

## Important

This email-sized package is intended for immediate method and code review. The large
feature tensors and support-bank checkpoints required to execute the full 35,665-image
replay are in `FishONet_v109_Reproducibility_Package.zip`, shared separately through
Google Drive. Extract the full package to run:

```bash
conda env create -f environment.yml
conda activate onet
python verify_package.py
python builders/build_v109_genus_gamble.py
python verify_prediction.py
```

The compact package includes the submitted `prediction.json` and Codabench submission
ZIP under `reference/`, allowing the organizer to inspect the exact delivered output
without downloading the larger checkpoint bundle first.

## Included method sources

- Official v109 and strict per-image compliance builders
- Proposed quota-gate training and frozen calibration
- Leak-free seen and unseen candidate re-rankers
- Hierarchical genus backoff training/evaluation
- AM-Softmax/CosFace encoder adaptation sources
- Crop-view, TaxaBind, BioCLIP-2, text, and support-bank extractors
- Environment, rules, disclosure, class index, and training labels

See the separately attached PDF for the full methodology and ablations.
